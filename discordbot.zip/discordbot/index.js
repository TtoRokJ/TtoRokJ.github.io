// 1. 주요 클래스 가져오기
const { Client, Events, GatewayIntentBits } = require('discord.js');
const { token } = require('./config.json');

// 2. 클라이언트 객체 생성 (Guilds관련, 메시지관련 인텐트 추가)
const client = new Client({ intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates, // 음성 상태 감지
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
]});

// 3. 봇이 준비됐을때 한번만(once) 표시할 메시지
client.once(Events.ClientReady, readyClient => {
console.log(`Ready! Logged in as ${readyClient.user.tag}`);
});

// 4. 누군가 ping을 작성하면 pong으로 답장한다.
client.on('messageCreate', (message) => {
    if(message.content == 'ping'){
        message.reply('pong');
    }
})

// 음성 채널 입장 & 퇴장 감지
client.on(Events.VoiceStateUpdate, (oldState, newState) => {
    const textChannel = newState.guild.channels.cache.find(
        (ch) => ch.name === '대기실' && ch.isTextBased()
    ); // 메시지를 보낼 채팅 채널 (이름 '일반')

    if (!textChannel) return; // 채팅 채널이 없으면 종료

    // 사용자의 서버 별명 가져오기 (없으면 기본 사용자명)
    const member = newState.member || oldState.member;
    const displayName = member.nickname || member.user.username;

    let messageContent = "";

    // ✅ 사용자가 음성 채널에 "입장"한 경우
    if (!oldState.channel && newState.channel) {
        messageContent = `🎤 **${displayName}** 님이 **${newState.channel.name}** 채널에 입장했습니다!`;
    }

    // ✅ 사용자가 음성 채널에서 "퇴장"한 경우
    if (oldState.channel && !newState.channel) {
        messageContent = `🚪 **${displayName}** 님이 **${oldState.channel.name}** 채널에서 퇴장했습니다.`;
    }

    // 메시지가 비어 있지 않으면 전송 후 10초 뒤 삭제
    if (messageContent) {
        textChannel.send(messageContent).then((sentMessage) => {
            setTimeout(() => {
                sentMessage.delete().catch(console.error);
            }, 10000); // 10초 후 삭제 (10000ms)
        });
    }
});


// 5. 시크릿키(토큰)을 통해 봇 로그인 실행
client.login(token);